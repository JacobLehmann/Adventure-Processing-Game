Extra Credit Details

	We implemented the use of the Accelerometer for our game, and we have it in the GameScene.swift file. We believe we deserve the extra credit points for adding this because it makes the game much more user friendly and interactive, such that the user can play the game on the go without the need to press the physical buttons on screen. Users are more used to the accelerometer in many mobile games, and we wanted to support that.
